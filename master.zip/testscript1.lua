require('Inspired')
require('IAC')
pcall( require, GetObjectName(GetMyHero()) ) 