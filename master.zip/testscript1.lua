require('Inspired')
require('IWalk')
pcall( require, GetObjectName(GetMyHero()) ) 