require('Inspired')
require('IMenu')
require('IWalk')
pcall( require, GetObjectName(GetMyHero()) ) 