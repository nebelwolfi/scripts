require('Inspired')
require('IAC')
require('WardJump')
pcall( require, GetObjectName(GetMyHero()) ) 