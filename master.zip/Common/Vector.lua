function Vector(x,y,z)
	local Vector = {}
	Vector.x = x
	Vector.y = y
	Vector.z = z
	Vector:unpack = function() return self.x, self.y, self.z end
	Vector:len2 = function(v) end
	Vector:dist = function(v) end
	Vector:normalize = function() end
	Vector:normalized = function() end
	Vector:rotate = function(phiX, phiY, phiZ) end
	Vector:rotated = function(phiX, phiY, phiZ) end
	Vector:projectOn = function(v) end
	Vector:mirrorOn = function(v) end
	Vector:center = function(v) end
	Vector:crossP = function() end
	Vector:dotP = function() end
	Vector:polar = function() end
	Vector:angleBetween = function(v1, v2) end
	Vector:compare = function(v) end
	Vector:perpendicular = function() end
	Vector:perpendicular2 = function() end
	local VectorOperations = {
		__type = function() return "Vector" end
		__add = function(v1, v2) return Vector(v1.x+v2.x, v1.y+v2.y, v1.z+v2.z) end
		__sub = function(v1, v2) return Vector(v1.x-v2.x, v1.y-v2.y, v1.z-v2.z) end
		__mul = function(a, b) return (type(a) == "number" and type(b) == "Vector") and Vector(b.x*a, b.y*a, b.z*a) or (type(a) == "Vector" and type(b) == "number") and Vector(a.x*b, a.y*b, a.z*b) or a:dotP(b)
		__div = function(a, b) return (type(a) == "number" and type(b) == "Vector") and Vector(a/b.x, a/b.y, a/b.z) or (type(a) == "Vector" and type(b) == "number") and Vector(b.x/a, b.y/a, b.z/a) or MessageBox(0,"Error1","Error2",0) end
	}
	setmetatable(Vector, VectorOperations)
	return Vector
end
--[[
function Vector.__lt(a, b)
    assert(VectorType(a) and VectorType(b), "__lt: wrong argument types (<Vector> expected)")
    return a:len() < b:len()
end

function Vector.__le(a, b)
    assert(VectorType(a) and VectorType(b), "__le: wrong argument types (<Vector> expected)")
    return a:len() <= b:len()
end

function Vector:__eq(v)
    assert(VectorType(v), "__eq: wrong argument types (<Vector> expected)")
    return self.x == v.x and self.y == v.y and self.z == v.z
end

function Vector:__unm() --redone, added check for y and z
    return Vector(-self.x, self.y and -self.y, self.z and -self.z)
end

function Vector:__vector(v)
    assert(VectorType(v), "__vector: wrong argument types (<Vector> expected)")
    return self:crossP(v)
end

function Vector:__tostring()
    if self.y and self.z then
        return "(" .. tostring(self.x) .. "," .. tostring(self.y) .. "," .. tostring(self.z) .. ")"
    else
        return "(" .. tostring(self.x) .. "," .. self.y and tostring(self.y) or tostring(self.z) .. ")"
    end
end
]]